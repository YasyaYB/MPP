import new as data

data.greet("Yoga")
from MuhammadYoga import Mahasiswa

p2 = Mahasiswa("Muhammad Yoga Ibnu Yasya", "19685", "SIJA")
p2.display_info()



