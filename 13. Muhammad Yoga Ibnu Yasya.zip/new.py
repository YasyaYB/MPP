def greet(nama):
    print("Halo," + nama)

    